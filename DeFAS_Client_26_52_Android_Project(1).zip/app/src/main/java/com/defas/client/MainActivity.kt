package com.defas.client

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.content.res.ColorStateList
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(11, 11, 16)
    private val panel = Color.rgb(25, 25, 34)
    private val panel2 = Color.rgb(33, 31, 44)
    private val purple = Color.rgb(166, 107, 255)
    private val muted = Color.rgb(155, 153, 170)
    private lateinit var content: LinearLayout
    private lateinit var tabRow: LinearLayout
    private var activeTab = "Visuals"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(18))
            background = gradient(bg, Color.rgb(22, 15, 35), 0)
        }

        val scroll = ScrollView(this).apply { isFillViewport = true }
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(page)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val logo = TextView(this).apply {
            text = "D"
            textSize = 25f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = gradient(purple, Color.rgb(103, 61, 190), 18)
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(48), dp(48)))
        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }
        titleBox.addView(text("DeFAS Client", 22, Color.WHITE, true))
        titleBox.addView(text("BEDROCK 26.52  •  ANDROID", 10, muted, true))
        header.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        val status = TextView(this).apply {
            text = "v0.3"
            textSize = 11f
            setTextColor(purple)
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = rounded(panel2, 30)
        }
        header.addView(status)
        page.addView(header)
        page.addView(space(22))

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = gradient(Color.rgb(38, 26, 59), Color.rgb(23, 22, 34), 22)
            elevation = dp(4).toFloat()
        }
        hero.addView(text("WELCOME BACK", 10, purple, true))
        hero.addView(space(5))
        hero.addView(text("Your game.\nYour settings.", 25, Color.WHITE, true))
        hero.addView(space(7))
        hero.addView(text("Companion interface for Minecraft Bedrock 26.52", 12, muted, false))
        page.addView(hero)
        page.addView(space(20))

        page.addView(text("MODULES", 11, muted, true))
        page.addView(space(8))
        tabRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Visuals", "World", "Tools").forEach { tab ->
            val b = tabButton(tab)
            tabRow.addView(b, LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                marginEnd = dp(6)
            })
        }
        page.addView(tabRow)
        page.addView(space(10))

        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(content)
        renderTab("Visuals")

        page.addView(space(18))
        val launch = button("OPEN MINECRAFT")
        launch.setOnClickListener {
            val i = packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
            if (i != null) startActivity(i)
            else Toast.makeText(this, "Minecraft Bedrock не знайдено", Toast.LENGTH_LONG).show()
        }
        page.addView(launch, LinearLayout.LayoutParams(-1, dp(52)))
        page.addView(space(10))
        page.addView(text("Build 0.3.0 • DeFAS Client", 10, muted, false))
        setContentView(root)

        // Intro animation: fade + rise, followed by a subtle logo pulse.
        page.alpha = 0f
        page.translationY = dp(22).toFloat()
        page.animate().alpha(1f).translationY(0f).setDuration(650)
            .setInterpolator(DecelerateInterpolator()).start()
        logo.animate().scaleX(1.08f).scaleY(1.08f).setDuration(700)
            .withEndAction {
                logo.animate().scaleX(1f).scaleY(1f).setDuration(700).start()
            }.start()
    }

    private fun renderTab(tab: String) {
        activeTab = tab
        content.removeAllViews()
        val entries = when (tab) {
            "World" -> listOf(
                Triple("Resource pack helper", "Open supported pack instructions", "PACK"),
                Triple("World settings", "Shortcuts for your own worlds", "WORLD"),
                Triple("Import guide", "How to import .mcpack files", "GUIDE")
            )
            "Tools" -> listOf(
                Triple("Coordinates guide", "Learn to enable coordinates in-world", "HUD"),
                Triple("Performance tips", "Settings that may improve performance", "FPS"),
                Triple("About DeFAS", "Project information and version", "INFO")
            )
            else -> listOf(
                Triple("FullBright pack", "Resource-pack based visual option", "VISUAL"),
                Triple("Coordinates HUD", "Use Bedrock world coordinate settings", "HUD"),
                Triple("Interface effects", "Animated companion app interface", "UI")
            )
        }
        entries.forEachIndexed { index, entry ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(13), dp(12), dp(13))
                background = rounded(panel, 16)
                alpha = 0f
                translationY = dp(12).toFloat()
            }
            val badge = TextView(this).apply {
                text = entry.third
                textSize = 9f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setTextColor(purple)
                background = rounded(panel2, 10)
                setPadding(dp(8), dp(9), dp(8), dp(9))
            }
            card.addView(badge)
            val labels = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), 0, 0, 0)
            }
            labels.addView(text(entry.first, 14, Color.WHITE, true))
            labels.addView(text(entry.second, 10, muted, false))
            card.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
            val arrow = TextView(this).apply {
                text = "›"
                textSize = 26f
                setTextColor(muted)
            }
            card.addView(arrow)
            card.setOnClickListener {
                card.animate().scaleX(0.98f).scaleY(0.98f).setDuration(80)
                    .withEndAction { card.animate().scaleX(1f).scaleY(1f).setDuration(100).start() }.start()
                Toast.makeText(this, entry.first + ": довідковий розділ", Toast.LENGTH_SHORT).show()
            }
            content.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
                bottomMargin = dp(8)
            })
            card.animate().alpha(1f).translationY(0f).setStartDelay(index * 75L)
                .setDuration(300).setInterpolator(DecelerateInterpolator()).start()
        }
        for (i in 0 until tabRow.childCount) {
            val v = tabRow.getChildAt(i) as TextView
            val selected = v.text.toString() == tab
            v.background = rounded(if (selected) purple else panel, 14)
            v.setTextColor(if (selected) Color.WHITE else muted)
        }
    }

    private fun tabButton(name: String) = TextView(this).apply {
        text = name
        gravity = Gravity.CENTER
        textSize = 12f
        typeface = Typeface.DEFAULT_BOLD
        setOnClickListener {
            if (activeTab != name) {
                content.animate().alpha(0f).translationY(dp(8).toFloat()).setDuration(120)
                    .withEndAction {
                        renderTab(name)
                        content.translationY = dp(8).toFloat()
                        content.animate().alpha(1f).translationY(0f).setDuration(220).start()
                    }.start()
            }
        }
    }

    private fun button(s: String) = TextView(this).apply {
        text = s
        gravity = Gravity.CENTER
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE)
        background = gradient(purple, Color.rgb(112, 67, 195), 16)
        isClickable = true
        isFocusable = true
        setOnTouchListener { v, e ->
            if (e.action == android.view.MotionEvent.ACTION_DOWN) {
                v.animate().scaleX(0.97f).scaleY(0.97f).setDuration(80).start()
            } else if (e.action == android.view.MotionEvent.ACTION_UP ||
                e.action == android.view.MotionEvent.ACTION_CANCEL) {
                v.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
            }
            false
        }
    }

    private fun text(s: String, size: Int, color: Int, bold: Boolean) =
        TextView(this).apply {
            text = s
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun space(h: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(h))
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun gradient(a: Int, b: Int, radius: Int) = GradientDrawable(
        GradientDrawable.Orientation.TL_BR, intArrayOf(a, b)
    ).apply { cornerRadius = dp(radius).toFloat() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
